#include <webots/Robot.hpp>
#include <webots/Motor.hpp>
#include <webots/DistanceSensor.hpp>

#define MAX_SPEED 6.28

using namespace webots;

int main() {
  Robot robot;
  Motor *leftMotor = robot.getMotor("left wheel motor");
  Motor *rightMotor = robot.getMotor("right wheel motor");
  
  DistanceSensor *leftSensor = robot.getDistanceSensor("left line sensor");
  DistanceSensor *rightSensor = robot.getDistanceSensor("right line sensor");
  
  leftSensor->enable(10);
  rightSensor->enable(10);

  while (robot.step(16) != -1) {
    double leftSensorValue = leftSensor->getValue();
    double rightSensorValue = rightSensor->getValue();

    double leftSpeed = MAX_SPEED * (1 - leftSensorValue / 4096.0);
    double rightSpeed = MAX_SPEED * (1 - rightSensorValue / 4096.0);

    leftMotor->setVelocity(leftSpeed);
    rightMotor->setVelocity(rightSpeed);
  }

  return 0;
}
