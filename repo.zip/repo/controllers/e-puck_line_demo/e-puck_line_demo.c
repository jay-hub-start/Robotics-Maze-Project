if (g[0] > 500 and g[1] < 350 and g[2] > 500): 
# drive straight 
	phildot, phirdot = MAX_SPEED, MAX_SPEED
elif (g[2] < 550):  
# turn right
	phildot, phirdot = 0.25 *MAX_SPEED, -0.1 * MAX_SPEED
… …
leftMotor.setVelocity(phildot)
rightMotor.setVelocity(phirdot)


